package weloveclouds.commons.status;

/**
 * Created by Benoit on 2016-11-30.
 */
public enum ServiceStatus {
    INITIALIZED, UNINITIALIZED, RUNNING, HALTED, WAITING, ERROR
}
