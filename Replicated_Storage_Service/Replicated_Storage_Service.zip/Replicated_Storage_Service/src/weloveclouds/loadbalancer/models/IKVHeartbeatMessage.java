package weloveclouds.loadbalancer.models;

/**
 * Created by Benoit on 2016-12-21.
 */
public interface IKVHeartbeatMessage {
    NodeHealthInfos getNodeHealthInfos();
}
