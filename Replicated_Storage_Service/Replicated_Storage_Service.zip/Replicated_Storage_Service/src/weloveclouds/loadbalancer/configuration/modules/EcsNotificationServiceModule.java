package weloveclouds.loadbalancer.configuration.modules;

import com.google.inject.AbstractModule;

/**
 * Created by Benoit on 2016-12-21.
 */
public class EcsNotificationServiceModule extends AbstractModule {
    @Override
    protected void configure() {

    }
}
