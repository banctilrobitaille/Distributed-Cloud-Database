package weloveclouds.loadbalancer.core;

/**
 * Created by Benoit on 2016-12-06.
 */
public interface ILoadBalancer {
    void start();
}
