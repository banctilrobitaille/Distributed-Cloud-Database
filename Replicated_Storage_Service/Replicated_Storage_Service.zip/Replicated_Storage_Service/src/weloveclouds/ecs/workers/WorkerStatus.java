package weloveclouds.ecs.workers;

/**
 * Created by Benoit on 2016-11-19.
 */
public enum WorkerStatus {
    RUNNING, FINISHED, ERROR, WAITING
}
